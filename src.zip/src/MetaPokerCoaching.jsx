
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function MetaPokerCoaching() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Thanks for reaching out! I'll get back to you soon.");
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-gray-800 text-white p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-600">
          Meta Poker Coaching
        </h1>
        <p className="mt-4 text-lg max-w-xl mx-auto text-gray-300">
          Not just poker coaching—it's a philosophy, a mindset, a revolution. Learn advanced strategy and meta-thinking from someone who truly understands the low-stakes MTT battlefield.
        </p>
      </header>

      <main className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <Card className="bg-gray-900 border border-gray-700 shadow-xl rounded-2xl p-4">
            <CardContent>
              <h2 className="text-2xl font-semibold mb-2">My Background</h2>
              <p className="text-gray-400 mb-4">
                I'm a consistent winner in low-stakes MTTs with deep knowledge of the player pool and common tendencies. I previously coached in Daniel Cates aka Jungleman's private Discord, both in group settings and 1-on-1 sessions. That experience shaped my approach to the game and teaching.
              </p>
              <Button className="bg-yellow-400 text-black font-bold hover:bg-yellow-500">
                Join the Meta
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
          <Card className="bg-gray-900 border border-gray-700 shadow-xl rounded-2xl p-4">
            <CardContent>
              <h2 className="text-2xl font-semibold mb-2">What's Offered</h2>
              <p className="text-gray-400 mb-4">
                I offer a full poker education experience: structured school, thematic classes, interactive quizzes, study sessions, and one-on-one coaching tailored to your needs and goals.
              </p>
              <Button className="bg-pink-500 hover:bg-pink-600 font-bold">
                Level Up Now
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.0 }}>
          <Card className="bg-gray-900 border border-gray-700 shadow-xl rounded-2xl p-4 md:col-span-2">
            <CardContent>
              <h2 className="text-2xl font-semibold mb-2">Book a Session</h2>
              <p className="text-gray-400 mb-4">
                Ready to take your game to the next level? Fill out the form below and let's build your edge together.
              </p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input type="text" name="name" placeholder="Your Name" value={formData.name} onChange={handleChange} required />
                <Input type="email" name="email" placeholder="Your Email" value={formData.email} onChange={handleChange} required />
                <Textarea name="message" placeholder="What do you want to work on?" value={formData.message} onChange={handleChange} rows={4} required />
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700 font-bold">
                  Submit
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2 }}>
          <Card className="bg-gray-900 border border-gray-700 shadow-xl rounded-2xl p-4 md:col-span-2">
            <CardContent>
              <h2 className="text-2xl font-semibold mb-2">Testimonials</h2>
              <p className="text-gray-400 mb-4">
                "This coaching changed how I see the game. The reads, the mindset, the edge—next level." — <i>Alex G.</i>
              </p>
              <p className="text-gray-400 mb-4">
                "I was stuck in the micros for months. After just two sessions, I started cashing consistently." — <i>Maria T.</i>
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </main>

      <footer className="text-center mt-16 text-sm text-gray-500">
        Built with heart & hustle — MetaPokerCoaching © 2025
      </footer>
    </div>
  );
}
