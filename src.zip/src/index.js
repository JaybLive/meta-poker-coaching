
import React from "react";
import ReactDOM from "react-dom/client";
import MetaPokerCoaching from "./MetaPokerCoaching";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <MetaPokerCoaching />
  </React.StrictMode>
);
